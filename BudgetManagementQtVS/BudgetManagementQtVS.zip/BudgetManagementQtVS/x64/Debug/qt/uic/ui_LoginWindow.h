/********************************************************************************
** Form generated from reading UI file 'LoginWindow.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINWINDOW_H
#define UI_LOGINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginWindow
{
public:
    QWidget *centralwidget;
    QLineEdit *editUsername;
    QLineEdit *editPassword;
    QPushButton *buttonLogin;
    QPushButton *buttonRegister;
    QPushButton *buttonCancel;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *LoginWindow)
    {
        if (LoginWindow->objectName().isEmpty())
            LoginWindow->setObjectName("LoginWindow");
        LoginWindow->resize(800, 600);
        centralwidget = new QWidget(LoginWindow);
        centralwidget->setObjectName("centralwidget");
        editUsername = new QLineEdit(centralwidget);
        editUsername->setObjectName("editUsername");
        editUsername->setGeometry(QRect(270, 50, 201, 71));
        editPassword = new QLineEdit(centralwidget);
        editPassword->setObjectName("editPassword");
        editPassword->setGeometry(QRect(270, 150, 201, 81));
        buttonLogin = new QPushButton(centralwidget);
        buttonLogin->setObjectName("buttonLogin");
        buttonLogin->setGeometry(QRect(60, 350, 121, 41));
        buttonRegister = new QPushButton(centralwidget);
        buttonRegister->setObjectName("buttonRegister");
        buttonRegister->setGeometry(QRect(260, 350, 121, 41));
        buttonCancel = new QPushButton(centralwidget);
        buttonCancel->setObjectName("buttonCancel");
        buttonCancel->setGeometry(QRect(450, 350, 121, 41));
        LoginWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(LoginWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 800, 21));
        LoginWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(LoginWindow);
        statusbar->setObjectName("statusbar");
        LoginWindow->setStatusBar(statusbar);

        retranslateUi(LoginWindow);

        QMetaObject::connectSlotsByName(LoginWindow);
    } // setupUi

    void retranslateUi(QMainWindow *LoginWindow)
    {
        LoginWindow->setWindowTitle(QCoreApplication::translate("LoginWindow", "MainWindow", nullptr));
        buttonLogin->setText(QCoreApplication::translate("LoginWindow", "Login", nullptr));
        buttonRegister->setText(QCoreApplication::translate("LoginWindow", "Register", nullptr));
        buttonCancel->setText(QCoreApplication::translate("LoginWindow", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginWindow: public Ui_LoginWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINWINDOW_H
