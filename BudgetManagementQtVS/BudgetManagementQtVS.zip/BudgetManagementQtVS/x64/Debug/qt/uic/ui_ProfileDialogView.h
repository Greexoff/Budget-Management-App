/********************************************************************************
** Form generated from reading UI file 'ProfileDialogView.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROFILEDIALOGVIEW_H
#define UI_PROFILEDIALOGVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ProfileDialog
{
public:
    QListWidget *listProfiles;
    QPushButton *buttonSelect;
    QPushButton *buttonAdd;
    QPushButton *buttonRemove;
    QPushButton *buttonCancel;

    void setupUi(QDialog *ProfileDialog)
    {
        if (ProfileDialog->objectName().isEmpty())
            ProfileDialog->setObjectName("ProfileDialog");
        ProfileDialog->resize(400, 300);
        listProfiles = new QListWidget(ProfileDialog);
        listProfiles->setObjectName("listProfiles");
        listProfiles->setGeometry(QRect(0, 20, 391, 191));
        buttonSelect = new QPushButton(ProfileDialog);
        buttonSelect->setObjectName("buttonSelect");
        buttonSelect->setGeometry(QRect(0, 240, 80, 24));
        buttonAdd = new QPushButton(ProfileDialog);
        buttonAdd->setObjectName("buttonAdd");
        buttonAdd->setGeometry(QRect(100, 240, 80, 24));
        buttonRemove = new QPushButton(ProfileDialog);
        buttonRemove->setObjectName("buttonRemove");
        buttonRemove->setGeometry(QRect(200, 240, 80, 24));
        buttonCancel = new QPushButton(ProfileDialog);
        buttonCancel->setObjectName("buttonCancel");
        buttonCancel->setGeometry(QRect(300, 240, 80, 24));

        retranslateUi(ProfileDialog);

        QMetaObject::connectSlotsByName(ProfileDialog);
    } // setupUi

    void retranslateUi(QDialog *ProfileDialog)
    {
        ProfileDialog->setWindowTitle(QCoreApplication::translate("ProfileDialog", "Wybierz profil", nullptr));
        buttonSelect->setText(QCoreApplication::translate("ProfileDialog", "Select", nullptr));
        buttonAdd->setText(QCoreApplication::translate("ProfileDialog", "Add", nullptr));
        buttonRemove->setText(QCoreApplication::translate("ProfileDialog", "Remove", nullptr));
        buttonCancel->setText(QCoreApplication::translate("ProfileDialog", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProfileDialog: public Ui_ProfileDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROFILEDIALOGVIEW_H
