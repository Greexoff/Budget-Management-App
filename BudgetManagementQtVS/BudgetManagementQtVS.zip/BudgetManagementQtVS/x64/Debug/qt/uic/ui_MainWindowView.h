/********************************************************************************
** Form generated from reading UI file 'MainWindowView.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOWVIEW_H
#define UI_MAINWINDOWVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QTableView *TransactionTabelView;
    QPushButton *buttonAddTransaction;
    QPushButton *buttonDeleteTransaction;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(600, 400);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName("centralWidget");
        TransactionTabelView = new QTableView(centralWidget);
        TransactionTabelView->setObjectName("TransactionTabelView");
        TransactionTabelView->setGeometry(QRect(0, 20, 601, 191));
        buttonAddTransaction = new QPushButton(centralWidget);
        buttonAddTransaction->setObjectName("buttonAddTransaction");
        buttonAddTransaction->setGeometry(QRect(170, 260, 111, 24));
        buttonDeleteTransaction = new QPushButton(centralWidget);
        buttonDeleteTransaction->setObjectName("buttonDeleteTransaction");
        buttonDeleteTransaction->setGeometry(QRect(390, 260, 101, 24));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 600, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName("mainToolBar");
        MainWindow->addToolBar(Qt::ToolBarArea::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName("statusBar");
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindowView", nullptr));
        buttonAddTransaction->setText(QCoreApplication::translate("MainWindow", "Dodaj transakcj\304\231", nullptr));
        buttonDeleteTransaction->setText(QCoreApplication::translate("MainWindow", "Usu\305\204 Transakcj\304\231", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOWVIEW_H
