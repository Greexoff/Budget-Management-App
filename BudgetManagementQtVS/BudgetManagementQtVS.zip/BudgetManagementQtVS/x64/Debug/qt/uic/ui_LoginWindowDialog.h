/********************************************************************************
** Form generated from reading UI file 'LoginWindowDialog.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINWINDOWDIALOG_H
#define UI_LOGINWINDOWDIALOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLineEdit *editUsername;
    QLineEdit *editPassword;
    QPushButton *buttonLogin;
    QPushButton *buttonRegister;
    QPushButton *buttonCancel;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName("Dialog");
        Dialog->resize(400, 300);
        editUsername = new QLineEdit(Dialog);
        editUsername->setObjectName("editUsername");
        editUsername->setGeometry(QRect(120, 30, 141, 41));
        editPassword = new QLineEdit(Dialog);
        editPassword->setObjectName("editPassword");
        editPassword->setGeometry(QRect(120, 90, 141, 41));
        buttonLogin = new QPushButton(Dialog);
        buttonLogin->setObjectName("buttonLogin");
        buttonLogin->setGeometry(QRect(60, 210, 80, 24));
        buttonRegister = new QPushButton(Dialog);
        buttonRegister->setObjectName("buttonRegister");
        buttonRegister->setGeometry(QRect(160, 210, 80, 24));
        buttonCancel = new QPushButton(Dialog);
        buttonCancel->setObjectName("buttonCancel");
        buttonCancel->setGeometry(QRect(260, 210, 80, 24));

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        editUsername->setText(QString());
        buttonLogin->setText(QCoreApplication::translate("Dialog", "Login", nullptr));
        buttonRegister->setText(QCoreApplication::translate("Dialog", "Register", nullptr));
        buttonCancel->setText(QCoreApplication::translate("Dialog", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINWINDOWDIALOG_H
