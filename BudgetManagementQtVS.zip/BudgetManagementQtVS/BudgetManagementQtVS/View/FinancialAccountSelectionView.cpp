﻿#include "FinancialAccountSelectionView.h"

FinancialAccountSelectionView::FinancialAccountSelectionView(QWidget* parent)
	: QDialog(parent), ui(new Ui::FinancialAccountSelectionView) {

	ui->setupUi(this);
	setWindowTitle("Browse financial accounts");
	setupTable();
	connectMethodToButton();
}

FinancialAccountSelectionView::~FinancialAccountSelectionView() {
	delete ui;
}


//----------------Setting connection (button-method)-------------------------------------------------


void FinancialAccountSelectionView::connectMethodToButton() {
	connect(ui->addFinancialAccountButton, &QPushButton::clicked, this, &FinancialAccountSelectionView::addFinancialAccountButtonClicked);
	connect(ui->deleteFinancialAccountButton, &QPushButton::clicked, this, &FinancialAccountSelectionView::deleteFinancialAccountButtonClicked);
	connect(ui->cancelFinancialAccountButton, &QPushButton::clicked, this, &FinancialAccountSelectionView::cancelFinancialAccountButtonClicked);
	connect(ui->editFinancialAccountButton, &QPushButton::clicked, this, &FinancialAccountSelectionView::editFinancialAccountButtonClicked);
	connect(ui->searchEdit, &QLineEdit::textChanged, this, &FinancialAccountSelectionView::searchTextChanged);

	QHeaderView* header = ui->financialAccountsTable->horizontalHeader();
	connect(header, &QHeaderView::sectionClicked, this, &FinancialAccountSelectionView::onColumnHeaderClicked);
}


//----------------Setting up view-------------------------------------------------


void FinancialAccountSelectionView::setupTable() {
	ui->financialAccountsTable->setColumnCount(3);

	ui->financialAccountsTable->setHorizontalHeaderLabels({ "Name", "Type", "Balance" });

	ui->financialAccountsTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

	ui->financialAccountsTable->verticalHeader()->setVisible(false);
	ui->financialAccountsTable->setSelectionBehavior(QAbstractItemView::SelectRows);
	ui->financialAccountsTable->setSelectionMode(QAbstractItemView::SingleSelection);
}


void FinancialAccountSelectionView::setFinancialAccounts(const QVector<FinancialAccount>& financialAccounts) {
	financialAccountId = financialAccounts;

	ui->financialAccountsTable->setRowCount(0);

	for (const auto& account : financialAccountId) {

		int row = ui->financialAccountsTable->rowCount();
		ui->financialAccountsTable->insertRow(row);

		ui->financialAccountsTable->setItem(row, 0, new QTableWidgetItem(account.getFinancialAccountName()));

		ui->financialAccountsTable->setItem(row, 1, new QTableWidgetItem(account.getFinancialAccountType()));

		QString balanceStr = QString::number(account.getFinancialAccountBalance(), 'f', 2) + " PLN";
		ui->financialAccountsTable->setItem(row, 2, new QTableWidgetItem(balanceStr));
	}
}


//----------------Pressing buttons actions-------------------------------------------------

//Method that notices clicking on add button
void FinancialAccountSelectionView::addFinancialAccountButtonClicked() {
	QDialog dlg(this);
	dlg.setWindowTitle(tr("New Financial Account"));

	QFormLayout* layout = new QFormLayout(&dlg);

	QLineEdit* nameEdit = new QLineEdit(&dlg);
	nameEdit->setPlaceholderText("e.g. mBank, Wallet");

	QComboBox* typeCombo = new QComboBox(&dlg);
	typeCombo->addItems({ "Cash", "Bank Account", "Savings", "Credit Card" });

	QDoubleSpinBox* balanceSpin = new QDoubleSpinBox(&dlg);
	balanceSpin->setRange(-10000000.0, 10000000.0); 
	balanceSpin->setDecimals(2);
	balanceSpin->setSuffix(" PLN");

	layout->addRow(tr("Account Name:"), nameEdit);
	layout->addRow(tr("Account Type:"), typeCombo);
	layout->addRow(tr("Initial Balance:"), balanceSpin);

	QDialogButtonBox* buttonBox = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Cancel, &dlg);
	layout->addRow(buttonBox);

	connect(buttonBox, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
	connect(buttonBox, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);

	if (dlg.exec() == QDialog::Accepted) {
		QString name = nameEdit->text();

		if (name.trimmed().isEmpty()) {
			return;
		}

		emit addRequestedFinancialAccount(name, typeCombo->currentText(), balanceSpin->value());
	}
}

//Method that notices clicking on edit button
void FinancialAccountSelectionView::editFinancialAccountButtonClicked() {
	int row = ui->financialAccountsTable->currentRow();

	if (row < 0 || row >= financialAccountId.size()) {
		return;
	}
	FinancialAccount currentFinancialAccount = financialAccountId[0];

	QString currentNameInTable = ui->financialAccountsTable->item(row, 0)->text();
	for (const auto& acc : financialAccountId) {
		if (acc.getFinancialAccountName() == currentNameInTable) {
			currentFinancialAccount = acc;
			break;
		}
	}

	if (currentFinancialAccount.getFinancialAccountId() == 1) {
		showFinancialAccountMessage(tr("Error"), tr("Cannot edit default account."), "error");
		return;
	}

	QDialog dlg(this);
	dlg.setWindowTitle(tr("Edit Financial Account"));
	QFormLayout* layout = new QFormLayout(&dlg);

	QLineEdit* nameEdit = new QLineEdit(&dlg);
	nameEdit->setText(currentFinancialAccount.getFinancialAccountName());

	QComboBox* typeCombo = new QComboBox(&dlg);
	typeCombo->addItems({ "Cash", "Bank Account", "Savings", "Credit Card" });
	typeCombo->setCurrentText(currentFinancialAccount.getFinancialAccountType());

	QDoubleSpinBox* balanceSpin = new QDoubleSpinBox(&dlg);
	balanceSpin->setRange(-10000000.0, 10000000.0);
	balanceSpin->setSuffix(" PLN");
	balanceSpin->setValue(currentFinancialAccount.getFinancialAccountBalance());

	layout->addRow(tr("Name:"), nameEdit);
	layout->addRow(tr("Type:"), typeCombo);
	layout->addRow(tr("Balance:"), balanceSpin);

	QDialogButtonBox* buttonBox = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Cancel, &dlg);
	layout->addRow(buttonBox);

	connect(buttonBox, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
	connect(buttonBox, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);

	if (dlg.exec() == QDialog::Accepted) {
		QString newName = nameEdit->text();
		if (newName.trimmed().isEmpty()) return;

		emit editRequestedFinancialAccount(currentFinancialAccount.getFinancialAccountId(), newName, typeCombo->currentText(), balanceSpin->value());
	}
}

//Method that notices clicking on delete button
void FinancialAccountSelectionView::deleteFinancialAccountButtonClicked() {
	
	int row = ui->financialAccountsTable->currentRow();
	if (row < 0 || row >= financialAccountId.size()) {
		return;
	}

	emit deleteRequestedFinancialAccount(financialAccountId[row].getFinancialAccountId());
}

//Method that notices clicking on cancel button
void FinancialAccountSelectionView::cancelFinancialAccountButtonClicked() {
	reject();
}

//Method that clears search bar while reentering view
void FinancialAccountSelectionView::clearSearchLineEdit()
{
	ui->searchEdit->clear();
}

//Method that passes text inserted in search bar
void FinancialAccountSelectionView::searchTextChanged(const QString& searchText)
{
	emit searchTextRequest(searchText);
}

//Method that notices clicking on column header
void FinancialAccountSelectionView::onColumnHeaderClicked(int columnId)
{
	emit columnSortRequest(columnId);
}

//Method responsible for displaying error if inserted data is incorrect/is lacking 
void FinancialAccountSelectionView::showFinancialAccountMessage(QString header, QString message, QString messageType) {
	if (messageType == "error")
	{
		QMessageBox::warning(this, header, message);
	}
	else
	{
		QMessageBox::information(this, header, message);
	}
}
