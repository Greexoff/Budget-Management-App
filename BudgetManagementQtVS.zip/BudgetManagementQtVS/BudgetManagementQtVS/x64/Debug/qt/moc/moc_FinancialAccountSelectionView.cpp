/****************************************************************************
** Meta object code from reading C++ file 'FinancialAccountSelectionView.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../View/FinancialAccountSelectionView.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'FinancialAccountSelectionView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN29FinancialAccountSelectionViewE_t {};
} // unnamed namespace

template <> constexpr inline auto FinancialAccountSelectionView::qt_create_metaobjectdata<qt_meta_tag_ZN29FinancialAccountSelectionViewE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "FinancialAccountSelectionView",
        "selectRequestedFinancialAccount",
        "",
        "financialAccountId",
        "addRequestedFinancialAccount",
        "financialAccountName",
        "financialAccountType",
        "financialAccount_balance",
        "deleteRequestedFinancialAccount",
        "editRequestedFinancialAccount",
        "name",
        "type",
        "balance",
        "searchTextRequest",
        "searchText",
        "columnSortRequest",
        "columnId",
        "showFinancialAccountMessage",
        "header",
        "message",
        "messageType",
        "addFinancialAccountButtonClicked",
        "deleteFinancialAccountButtonClicked",
        "editFinancialAccountButtonClicked",
        "cancelFinancialAccountButtonClicked",
        "searchTextChanged",
        "onColumnHeaderClicked"
    };

    QtMocHelpers::UintData qt_methods {
        // Signal 'selectRequestedFinancialAccount'
        QtMocHelpers::SignalData<void(int)>(1, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 3 },
        }}),
        // Signal 'addRequestedFinancialAccount'
        QtMocHelpers::SignalData<void(const QString &, const QString &, double)>(4, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 5 }, { QMetaType::QString, 6 }, { QMetaType::Double, 7 },
        }}),
        // Signal 'deleteRequestedFinancialAccount'
        QtMocHelpers::SignalData<void(int)>(8, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 3 },
        }}),
        // Signal 'editRequestedFinancialAccount'
        QtMocHelpers::SignalData<void(int, const QString &, const QString &, double)>(9, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 3 }, { QMetaType::QString, 10 }, { QMetaType::QString, 11 }, { QMetaType::Double, 12 },
        }}),
        // Signal 'searchTextRequest'
        QtMocHelpers::SignalData<void(const QString &)>(13, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 14 },
        }}),
        // Signal 'columnSortRequest'
        QtMocHelpers::SignalData<void(int)>(15, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 16 },
        }}),
        // Slot 'showFinancialAccountMessage'
        QtMocHelpers::SlotData<void(QString, QString, QString)>(17, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 18 }, { QMetaType::QString, 19 }, { QMetaType::QString, 20 },
        }}),
        // Slot 'addFinancialAccountButtonClicked'
        QtMocHelpers::SlotData<void()>(21, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'deleteFinancialAccountButtonClicked'
        QtMocHelpers::SlotData<void()>(22, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'editFinancialAccountButtonClicked'
        QtMocHelpers::SlotData<void()>(23, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'cancelFinancialAccountButtonClicked'
        QtMocHelpers::SlotData<void()>(24, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'searchTextChanged'
        QtMocHelpers::SlotData<void(const QString &)>(25, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 14 },
        }}),
        // Slot 'onColumnHeaderClicked'
        QtMocHelpers::SlotData<void(int)>(26, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 16 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<FinancialAccountSelectionView, qt_meta_tag_ZN29FinancialAccountSelectionViewE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject FinancialAccountSelectionView::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN29FinancialAccountSelectionViewE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN29FinancialAccountSelectionViewE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN29FinancialAccountSelectionViewE_t>.metaTypes,
    nullptr
} };

void FinancialAccountSelectionView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<FinancialAccountSelectionView *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->selectRequestedFinancialAccount((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->addRequestedFinancialAccount((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<double>>(_a[3]))); break;
        case 2: _t->deleteRequestedFinancialAccount((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->editRequestedFinancialAccount((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<double>>(_a[4]))); break;
        case 4: _t->searchTextRequest((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->columnSortRequest((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->showFinancialAccountMessage((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3]))); break;
        case 7: _t->addFinancialAccountButtonClicked(); break;
        case 8: _t->deleteFinancialAccountButtonClicked(); break;
        case 9: _t->editFinancialAccountButtonClicked(); break;
        case 10: _t->cancelFinancialAccountButtonClicked(); break;
        case 11: _t->searchTextChanged((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 12: _t->onColumnHeaderClicked((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        if (QtMocHelpers::indexOfMethod<void (FinancialAccountSelectionView::*)(int )>(_a, &FinancialAccountSelectionView::selectRequestedFinancialAccount, 0))
            return;
        if (QtMocHelpers::indexOfMethod<void (FinancialAccountSelectionView::*)(const QString & , const QString & , double )>(_a, &FinancialAccountSelectionView::addRequestedFinancialAccount, 1))
            return;
        if (QtMocHelpers::indexOfMethod<void (FinancialAccountSelectionView::*)(int )>(_a, &FinancialAccountSelectionView::deleteRequestedFinancialAccount, 2))
            return;
        if (QtMocHelpers::indexOfMethod<void (FinancialAccountSelectionView::*)(int , const QString & , const QString & , double )>(_a, &FinancialAccountSelectionView::editRequestedFinancialAccount, 3))
            return;
        if (QtMocHelpers::indexOfMethod<void (FinancialAccountSelectionView::*)(const QString & )>(_a, &FinancialAccountSelectionView::searchTextRequest, 4))
            return;
        if (QtMocHelpers::indexOfMethod<void (FinancialAccountSelectionView::*)(int )>(_a, &FinancialAccountSelectionView::columnSortRequest, 5))
            return;
    }
}

const QMetaObject *FinancialAccountSelectionView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FinancialAccountSelectionView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN29FinancialAccountSelectionViewE_t>.strings))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int FinancialAccountSelectionView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void FinancialAccountSelectionView::selectRequestedFinancialAccount(int _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 0, nullptr, _t1);
}

// SIGNAL 1
void FinancialAccountSelectionView::addRequestedFinancialAccount(const QString & _t1, const QString & _t2, double _t3)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 1, nullptr, _t1, _t2, _t3);
}

// SIGNAL 2
void FinancialAccountSelectionView::deleteRequestedFinancialAccount(int _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 2, nullptr, _t1);
}

// SIGNAL 3
void FinancialAccountSelectionView::editRequestedFinancialAccount(int _t1, const QString & _t2, const QString & _t3, double _t4)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 3, nullptr, _t1, _t2, _t3, _t4);
}

// SIGNAL 4
void FinancialAccountSelectionView::searchTextRequest(const QString & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 4, nullptr, _t1);
}

// SIGNAL 5
void FinancialAccountSelectionView::columnSortRequest(int _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 5, nullptr, _t1);
}
QT_WARNING_POP
