/****************************************************************************
** Meta object code from reading C++ file 'TransactionWindowView.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../View/TransactionWindowView.h"
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'TransactionWindowView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN17TransactionWindowE_t {};
} // unnamed namespace

template <> constexpr inline auto TransactionWindow::qt_create_metaobjectdata<qt_meta_tag_ZN17TransactionWindowE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "TransactionWindow",
        "addTransactionRequest",
        "",
        "deleteTransactionRequest",
        "showCategoriesRequest",
        "showFinancialAccountsRequest",
        "editTransactionRequest",
        "backToProfileRequested",
        "editBudgetRequest",
        "showChartsRequest",
        "columnSortRequest",
        "columnId",
        "searchTextRequest",
        "searchText",
        "showTransactionMessage",
        "header",
        "message",
        "messageType",
        "onButtonAddTransactionClicked",
        "onButtonDeleteTransactionClicked",
        "onButtonShowCategoriesClicked",
        "onButtonShowFinancialAccountsClicked",
        "onButtonEditTransactionClicked",
        "onButtonEditBudgetClicked",
        "onButtonChartsClicked",
        "onColumnHeaderClicked",
        "searchTextChanged"
    };

    QtMocHelpers::UintData qt_methods {
        // Signal 'addTransactionRequest'
        QtMocHelpers::SignalData<void()>(1, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'deleteTransactionRequest'
        QtMocHelpers::SignalData<void()>(3, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'showCategoriesRequest'
        QtMocHelpers::SignalData<void()>(4, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'showFinancialAccountsRequest'
        QtMocHelpers::SignalData<void()>(5, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'editTransactionRequest'
        QtMocHelpers::SignalData<void()>(6, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'backToProfileRequested'
        QtMocHelpers::SignalData<void()>(7, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'editBudgetRequest'
        QtMocHelpers::SignalData<void()>(8, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'showChartsRequest'
        QtMocHelpers::SignalData<void()>(9, 2, QMC::AccessPublic, QMetaType::Void),
        // Signal 'columnSortRequest'
        QtMocHelpers::SignalData<void(int)>(10, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 11 },
        }}),
        // Signal 'searchTextRequest'
        QtMocHelpers::SignalData<void(const QString &)>(12, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 13 },
        }}),
        // Slot 'showTransactionMessage'
        QtMocHelpers::SlotData<void(QString, QString, QString)>(14, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 15 }, { QMetaType::QString, 16 }, { QMetaType::QString, 17 },
        }}),
        // Slot 'onButtonAddTransactionClicked'
        QtMocHelpers::SlotData<void()>(18, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onButtonDeleteTransactionClicked'
        QtMocHelpers::SlotData<void()>(19, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onButtonShowCategoriesClicked'
        QtMocHelpers::SlotData<void()>(20, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onButtonShowFinancialAccountsClicked'
        QtMocHelpers::SlotData<void()>(21, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onButtonEditTransactionClicked'
        QtMocHelpers::SlotData<void()>(22, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onButtonEditBudgetClicked'
        QtMocHelpers::SlotData<void()>(23, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onButtonChartsClicked'
        QtMocHelpers::SlotData<void()>(24, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onColumnHeaderClicked'
        QtMocHelpers::SlotData<void(int)>(25, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 11 },
        }}),
        // Slot 'searchTextChanged'
        QtMocHelpers::SlotData<void(QString)>(26, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 13 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<TransactionWindow, qt_meta_tag_ZN17TransactionWindowE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject TransactionWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN17TransactionWindowE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN17TransactionWindowE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN17TransactionWindowE_t>.metaTypes,
    nullptr
} };

void TransactionWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<TransactionWindow *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->addTransactionRequest(); break;
        case 1: _t->deleteTransactionRequest(); break;
        case 2: _t->showCategoriesRequest(); break;
        case 3: _t->showFinancialAccountsRequest(); break;
        case 4: _t->editTransactionRequest(); break;
        case 5: _t->backToProfileRequested(); break;
        case 6: _t->editBudgetRequest(); break;
        case 7: _t->showChartsRequest(); break;
        case 8: _t->columnSortRequest((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 9: _t->searchTextRequest((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 10: _t->showTransactionMessage((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3]))); break;
        case 11: _t->onButtonAddTransactionClicked(); break;
        case 12: _t->onButtonDeleteTransactionClicked(); break;
        case 13: _t->onButtonShowCategoriesClicked(); break;
        case 14: _t->onButtonShowFinancialAccountsClicked(); break;
        case 15: _t->onButtonEditTransactionClicked(); break;
        case 16: _t->onButtonEditBudgetClicked(); break;
        case 17: _t->onButtonChartsClicked(); break;
        case 18: _t->onColumnHeaderClicked((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 19: _t->searchTextChanged((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)()>(_a, &TransactionWindow::addTransactionRequest, 0))
            return;
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)()>(_a, &TransactionWindow::deleteTransactionRequest, 1))
            return;
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)()>(_a, &TransactionWindow::showCategoriesRequest, 2))
            return;
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)()>(_a, &TransactionWindow::showFinancialAccountsRequest, 3))
            return;
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)()>(_a, &TransactionWindow::editTransactionRequest, 4))
            return;
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)()>(_a, &TransactionWindow::backToProfileRequested, 5))
            return;
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)()>(_a, &TransactionWindow::editBudgetRequest, 6))
            return;
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)()>(_a, &TransactionWindow::showChartsRequest, 7))
            return;
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)(int )>(_a, &TransactionWindow::columnSortRequest, 8))
            return;
        if (QtMocHelpers::indexOfMethod<void (TransactionWindow::*)(const QString & )>(_a, &TransactionWindow::searchTextRequest, 9))
            return;
    }
}

const QMetaObject *TransactionWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TransactionWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN17TransactionWindowE_t>.strings))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int TransactionWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 20;
    }
    return _id;
}

// SIGNAL 0
void TransactionWindow::addTransactionRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void TransactionWindow::deleteTransactionRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void TransactionWindow::showCategoriesRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void TransactionWindow::showFinancialAccountsRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void TransactionWindow::editTransactionRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void TransactionWindow::backToProfileRequested()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void TransactionWindow::editBudgetRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void TransactionWindow::showChartsRequest()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void TransactionWindow::columnSortRequest(int _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 8, nullptr, _t1);
}

// SIGNAL 9
void TransactionWindow::searchTextRequest(const QString & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 9, nullptr, _t1);
}
QT_WARNING_POP
