/****************************************************************************
** Meta object code from reading C++ file 'FinancialAccountSelectionController.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../Controller/FinancialAccountSelectionController.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'FinancialAccountSelectionController.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN26FinancialAccountControllerE_t {};
} // unnamed namespace

template <> constexpr inline auto FinancialAccountController::qt_create_metaobjectdata<qt_meta_tag_ZN26FinancialAccountControllerE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "FinancialAccountController",
        "financialAccountDataChanged",
        "",
        "setupFinancialAccountWindow",
        "handleFinancialAccountAddRequest",
        "financialAccountName",
        "financialAccountType",
        "financialAccountBalance",
        "handleFinancialAccountDeleteRequest",
        "financialAccountId",
        "handleFinancialAccountEditRequest",
        "id",
        "name",
        "type",
        "balance",
        "handleFinancialAccountFilteringRequest",
        "searchText",
        "handleSortingRequest",
        "columnId"
    };

    QtMocHelpers::UintData qt_methods {
        // Signal 'financialAccountDataChanged'
        QtMocHelpers::SignalData<void()>(1, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'setupFinancialAccountWindow'
        QtMocHelpers::SlotData<void()>(3, 2, QMC::AccessPublic, QMetaType::Void),
        // Slot 'handleFinancialAccountAddRequest'
        QtMocHelpers::SlotData<void(const QString &, const QString &, double)>(4, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 5 }, { QMetaType::QString, 6 }, { QMetaType::Double, 7 },
        }}),
        // Slot 'handleFinancialAccountDeleteRequest'
        QtMocHelpers::SlotData<void(int)>(8, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 9 },
        }}),
        // Slot 'handleFinancialAccountEditRequest'
        QtMocHelpers::SlotData<void(int, const QString &, const QString &, double)>(10, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 11 }, { QMetaType::QString, 12 }, { QMetaType::QString, 13 }, { QMetaType::Double, 14 },
        }}),
        // Slot 'handleFinancialAccountFilteringRequest'
        QtMocHelpers::SlotData<void(const QString &)>(15, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 16 },
        }}),
        // Slot 'handleSortingRequest'
        QtMocHelpers::SlotData<void(int)>(17, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 18 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<FinancialAccountController, qt_meta_tag_ZN26FinancialAccountControllerE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject FinancialAccountController::staticMetaObject = { {
    QMetaObject::SuperData::link<BaseController::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN26FinancialAccountControllerE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN26FinancialAccountControllerE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN26FinancialAccountControllerE_t>.metaTypes,
    nullptr
} };

void FinancialAccountController::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<FinancialAccountController *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->financialAccountDataChanged(); break;
        case 1: _t->setupFinancialAccountWindow(); break;
        case 2: _t->handleFinancialAccountAddRequest((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<double>>(_a[3]))); break;
        case 3: _t->handleFinancialAccountDeleteRequest((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 4: _t->handleFinancialAccountEditRequest((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<double>>(_a[4]))); break;
        case 5: _t->handleFinancialAccountFilteringRequest((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 6: _t->handleSortingRequest((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        if (QtMocHelpers::indexOfMethod<void (FinancialAccountController::*)()>(_a, &FinancialAccountController::financialAccountDataChanged, 0))
            return;
    }
}

const QMetaObject *FinancialAccountController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FinancialAccountController::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN26FinancialAccountControllerE_t>.strings))
        return static_cast<void*>(this);
    return BaseController::qt_metacast(_clname);
}

int FinancialAccountController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = BaseController::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void FinancialAccountController::financialAccountDataChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
