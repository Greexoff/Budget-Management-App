/****************************************************************************
** Meta object code from reading C++ file 'CategorySelectionView.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../View/CategorySelectionView.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CategorySelectionView.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN21CategorySelectionViewE_t {};
} // unnamed namespace

template <> constexpr inline auto CategorySelectionView::qt_create_metaobjectdata<qt_meta_tag_ZN21CategorySelectionViewE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "CategorySelectionView",
        "selectRequestedCategory",
        "",
        "categoryId",
        "addRequestedCategory",
        "categoryName",
        "deleteRequestedCategory",
        "editRequestedCategory",
        "newName",
        "searchTextRequest",
        "searchText",
        "columnSortRequest",
        "columnId",
        "showCategoryMessage",
        "header",
        "message",
        "messageType",
        "addCategoryButtonClicked",
        "deleteCategoryButtonClicked",
        "cancelButtonClicked",
        "editCategoryButtonClicked",
        "searchTextChanged",
        "onColumnHeaderClicked"
    };

    QtMocHelpers::UintData qt_methods {
        // Signal 'selectRequestedCategory'
        QtMocHelpers::SignalData<void(int)>(1, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 3 },
        }}),
        // Signal 'addRequestedCategory'
        QtMocHelpers::SignalData<void(const QString &)>(4, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 5 },
        }}),
        // Signal 'deleteRequestedCategory'
        QtMocHelpers::SignalData<void(int)>(6, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 3 },
        }}),
        // Signal 'editRequestedCategory'
        QtMocHelpers::SignalData<void(int, const QString &)>(7, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 3 }, { QMetaType::QString, 8 },
        }}),
        // Signal 'searchTextRequest'
        QtMocHelpers::SignalData<void(const QString &)>(9, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 10 },
        }}),
        // Signal 'columnSortRequest'
        QtMocHelpers::SignalData<void(int)>(11, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::Int, 12 },
        }}),
        // Slot 'showCategoryMessage'
        QtMocHelpers::SlotData<void(QString, QString, QString)>(13, 2, QMC::AccessPublic, QMetaType::Void, {{
            { QMetaType::QString, 14 }, { QMetaType::QString, 15 }, { QMetaType::QString, 16 },
        }}),
        // Slot 'addCategoryButtonClicked'
        QtMocHelpers::SlotData<void()>(17, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'deleteCategoryButtonClicked'
        QtMocHelpers::SlotData<void()>(18, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'cancelButtonClicked'
        QtMocHelpers::SlotData<void()>(19, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'editCategoryButtonClicked'
        QtMocHelpers::SlotData<void()>(20, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'searchTextChanged'
        QtMocHelpers::SlotData<void(const QString &)>(21, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 10 },
        }}),
        // Slot 'onColumnHeaderClicked'
        QtMocHelpers::SlotData<void(int)>(22, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 12 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<CategorySelectionView, qt_meta_tag_ZN21CategorySelectionViewE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject CategorySelectionView::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN21CategorySelectionViewE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN21CategorySelectionViewE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN21CategorySelectionViewE_t>.metaTypes,
    nullptr
} };

void CategorySelectionView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<CategorySelectionView *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->selectRequestedCategory((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->addRequestedCategory((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->deleteRequestedCategory((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->editRequestedCategory((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 4: _t->searchTextRequest((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->columnSortRequest((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->showCategoryMessage((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3]))); break;
        case 7: _t->addCategoryButtonClicked(); break;
        case 8: _t->deleteCategoryButtonClicked(); break;
        case 9: _t->cancelButtonClicked(); break;
        case 10: _t->editCategoryButtonClicked(); break;
        case 11: _t->searchTextChanged((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        case 12: _t->onColumnHeaderClicked((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    }
    if (_c == QMetaObject::IndexOfMethod) {
        if (QtMocHelpers::indexOfMethod<void (CategorySelectionView::*)(int )>(_a, &CategorySelectionView::selectRequestedCategory, 0))
            return;
        if (QtMocHelpers::indexOfMethod<void (CategorySelectionView::*)(const QString & )>(_a, &CategorySelectionView::addRequestedCategory, 1))
            return;
        if (QtMocHelpers::indexOfMethod<void (CategorySelectionView::*)(int )>(_a, &CategorySelectionView::deleteRequestedCategory, 2))
            return;
        if (QtMocHelpers::indexOfMethod<void (CategorySelectionView::*)(int , const QString & )>(_a, &CategorySelectionView::editRequestedCategory, 3))
            return;
        if (QtMocHelpers::indexOfMethod<void (CategorySelectionView::*)(const QString & )>(_a, &CategorySelectionView::searchTextRequest, 4))
            return;
        if (QtMocHelpers::indexOfMethod<void (CategorySelectionView::*)(int )>(_a, &CategorySelectionView::columnSortRequest, 5))
            return;
    }
}

const QMetaObject *CategorySelectionView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CategorySelectionView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN21CategorySelectionViewE_t>.strings))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int CategorySelectionView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 13;
    }
    return _id;
}

// SIGNAL 0
void CategorySelectionView::selectRequestedCategory(int _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 0, nullptr, _t1);
}

// SIGNAL 1
void CategorySelectionView::addRequestedCategory(const QString & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 1, nullptr, _t1);
}

// SIGNAL 2
void CategorySelectionView::deleteRequestedCategory(int _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 2, nullptr, _t1);
}

// SIGNAL 3
void CategorySelectionView::editRequestedCategory(int _t1, const QString & _t2)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 3, nullptr, _t1, _t2);
}

// SIGNAL 4
void CategorySelectionView::searchTextRequest(const QString & _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 4, nullptr, _t1);
}

// SIGNAL 5
void CategorySelectionView::columnSortRequest(int _t1)
{
    QMetaObject::activate<void>(this, &staticMetaObject, 5, nullptr, _t1);
}
QT_WARNING_POP
