/********************************************************************************
** Form generated from reading UI file 'ChartsDialogView.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHARTSDIALOGVIEW_H
#define UI_CHARTSDIALOGVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ChartsDialogViewClass
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout_3;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_2;

    void setupUi(QDialog *ChartsDialogViewClass)
    {
        if (ChartsDialogViewClass->objectName().isEmpty())
            ChartsDialogViewClass->setObjectName("ChartsDialogViewClass");
        ChartsDialogViewClass->resize(1000, 800);
        widget = new QWidget(ChartsDialogViewClass);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(50, 30, 891, 711));
        verticalLayout_3 = new QVBoxLayout(widget);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName("verticalLayout_3");
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName("verticalLayout");

        verticalLayout_3->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName("verticalLayout_2");

        verticalLayout_3->addLayout(verticalLayout_2);


        retranslateUi(ChartsDialogViewClass);

        QMetaObject::connectSlotsByName(ChartsDialogViewClass);
    } // setupUi

    void retranslateUi(QDialog *ChartsDialogViewClass)
    {
        ChartsDialogViewClass->setWindowTitle(QCoreApplication::translate("ChartsDialogViewClass", "ChartsDialogView", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ChartsDialogViewClass: public Ui_ChartsDialogViewClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHARTSDIALOGVIEW_H
