/********************************************************************************
** Form generated from reading UI file 'TransactionWindowView.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRANSACTIONWINDOWVIEW_H
#define UI_TRANSACTIONWINDOWVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QTableView *TransactionTabelView;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *buttonAddTransaction;
    QPushButton *buttonDeleteTransaction;
    QPushButton *buttonEdit;
    QPushButton *browseFinancialAccountsButton;
    QPushButton *browseCategoriesButton;
    QPushButton *buttonCharts;
    QPushButton *changeProfileButton;
    QProgressBar *budgetProgressBar;
    QLabel *budgetLabel;
    QPushButton *editBudgetButton;
    QLineEdit *searchEdit;
    QLabel *label;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1136, 614);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName("centralWidget");
        TransactionTabelView = new QTableView(centralWidget);
        TransactionTabelView->setObjectName("TransactionTabelView");
        TransactionTabelView->setGeometry(QRect(60, 60, 1011, 351));
        horizontalLayoutWidget = new QWidget(centralWidget);
        horizontalLayoutWidget->setObjectName("horizontalLayoutWidget");
        horizontalLayoutWidget->setGeometry(QRect(60, 430, 1011, 80));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        buttonAddTransaction = new QPushButton(horizontalLayoutWidget);
        buttonAddTransaction->setObjectName("buttonAddTransaction");

        horizontalLayout->addWidget(buttonAddTransaction);

        buttonDeleteTransaction = new QPushButton(horizontalLayoutWidget);
        buttonDeleteTransaction->setObjectName("buttonDeleteTransaction");

        horizontalLayout->addWidget(buttonDeleteTransaction);

        buttonEdit = new QPushButton(horizontalLayoutWidget);
        buttonEdit->setObjectName("buttonEdit");

        horizontalLayout->addWidget(buttonEdit);

        browseFinancialAccountsButton = new QPushButton(horizontalLayoutWidget);
        browseFinancialAccountsButton->setObjectName("browseFinancialAccountsButton");

        horizontalLayout->addWidget(browseFinancialAccountsButton);

        browseCategoriesButton = new QPushButton(horizontalLayoutWidget);
        browseCategoriesButton->setObjectName("browseCategoriesButton");

        horizontalLayout->addWidget(browseCategoriesButton);

        buttonCharts = new QPushButton(horizontalLayoutWidget);
        buttonCharts->setObjectName("buttonCharts");

        horizontalLayout->addWidget(buttonCharts);

        changeProfileButton = new QPushButton(horizontalLayoutWidget);
        changeProfileButton->setObjectName("changeProfileButton");

        horizontalLayout->addWidget(changeProfileButton);

        budgetProgressBar = new QProgressBar(centralWidget);
        budgetProgressBar->setObjectName("budgetProgressBar");
        budgetProgressBar->setGeometry(QRect(440, 10, 121, 31));
        budgetProgressBar->setValue(24);
        budgetLabel = new QLabel(centralWidget);
        budgetLabel->setObjectName("budgetLabel");
        budgetLabel->setGeometry(QRect(60, 10, 371, 31));
        editBudgetButton = new QPushButton(centralWidget);
        editBudgetButton->setObjectName("editBudgetButton");
        editBudgetButton->setGeometry(QRect(580, 10, 91, 31));
        searchEdit = new QLineEdit(centralWidget);
        searchEdit->setObjectName("searchEdit");
        searchEdit->setGeometry(QRect(940, 20, 113, 24));
        label = new QLabel(centralWidget);
        label->setObjectName("label");
        label->setGeometry(QRect(900, 20, 41, 21));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 1136, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName("mainToolBar");
        MainWindow->addToolBar(Qt::ToolBarArea::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName("statusBar");
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindowView", nullptr));
        buttonAddTransaction->setText(QCoreApplication::translate("MainWindow", "Add transaction", nullptr));
        buttonDeleteTransaction->setText(QCoreApplication::translate("MainWindow", "Delete transaction", nullptr));
        buttonEdit->setText(QCoreApplication::translate("MainWindow", "Edit transaction", nullptr));
        browseFinancialAccountsButton->setText(QCoreApplication::translate("MainWindow", "Browse financial accounts", nullptr));
        browseCategoriesButton->setText(QCoreApplication::translate("MainWindow", "Browse categories", nullptr));
        buttonCharts->setText(QCoreApplication::translate("MainWindow", "Charts", nullptr));
        changeProfileButton->setText(QCoreApplication::translate("MainWindow", "Back", nullptr));
        budgetLabel->setText(QCoreApplication::translate("MainWindow", "Budget: 0.00 PLN", nullptr));
        editBudgetButton->setText(QCoreApplication::translate("MainWindow", "Set budget", nullptr));
        searchEdit->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRANSACTIONWINDOWVIEW_H
