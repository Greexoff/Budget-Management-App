/********************************************************************************
** Form generated from reading UI file 'ProfileDialogView.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PROFILEDIALOGVIEW_H
#define UI_PROFILEDIALOGVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ProfileDialog
{
public:
    QListWidget *listProfiles;
    QPushButton *buttonSelect;
    QPushButton *buttonAdd;
    QPushButton *buttonRemove;
    QPushButton *buttonCancel;
    QPushButton *buttonEdit;
    QPushButton *buttonExport;
    QPushButton *logoutButton;

    void setupUi(QDialog *ProfileDialog)
    {
        if (ProfileDialog->objectName().isEmpty())
            ProfileDialog->setObjectName("ProfileDialog");
        ProfileDialog->resize(592, 297);
        listProfiles = new QListWidget(ProfileDialog);
        listProfiles->setObjectName("listProfiles");
        listProfiles->setGeometry(QRect(0, 20, 581, 201));
        buttonSelect = new QPushButton(ProfileDialog);
        buttonSelect->setObjectName("buttonSelect");
        buttonSelect->setGeometry(QRect(0, 240, 80, 24));
        buttonAdd = new QPushButton(ProfileDialog);
        buttonAdd->setObjectName("buttonAdd");
        buttonAdd->setGeometry(QRect(100, 240, 80, 24));
        buttonRemove = new QPushButton(ProfileDialog);
        buttonRemove->setObjectName("buttonRemove");
        buttonRemove->setGeometry(QRect(200, 240, 80, 24));
        buttonCancel = new QPushButton(ProfileDialog);
        buttonCancel->setObjectName("buttonCancel");
        buttonCancel->setGeometry(QRect(500, 240, 80, 24));
        buttonEdit = new QPushButton(ProfileDialog);
        buttonEdit->setObjectName("buttonEdit");
        buttonEdit->setGeometry(QRect(300, 240, 80, 24));
        buttonExport = new QPushButton(ProfileDialog);
        buttonExport->setObjectName("buttonExport");
        buttonExport->setGeometry(QRect(0, 270, 581, 24));
        logoutButton = new QPushButton(ProfileDialog);
        logoutButton->setObjectName("logoutButton");
        logoutButton->setGeometry(QRect(400, 240, 80, 24));

        retranslateUi(ProfileDialog);

        QMetaObject::connectSlotsByName(ProfileDialog);
    } // setupUi

    void retranslateUi(QDialog *ProfileDialog)
    {
        ProfileDialog->setWindowTitle(QCoreApplication::translate("ProfileDialog", "Select Profile", nullptr));
        buttonSelect->setText(QCoreApplication::translate("ProfileDialog", "Select", nullptr));
        buttonAdd->setText(QCoreApplication::translate("ProfileDialog", "Add", nullptr));
        buttonRemove->setText(QCoreApplication::translate("ProfileDialog", "Remove", nullptr));
        buttonCancel->setText(QCoreApplication::translate("ProfileDialog", "Exit", nullptr));
        buttonEdit->setText(QCoreApplication::translate("ProfileDialog", "Edit", nullptr));
        buttonExport->setText(QCoreApplication::translate("ProfileDialog", "Export Data to CSV", nullptr));
        logoutButton->setText(QCoreApplication::translate("ProfileDialog", "Logout", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProfileDialog: public Ui_ProfileDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PROFILEDIALOGVIEW_H
