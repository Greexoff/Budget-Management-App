/********************************************************************************
** Form generated from reading UI file 'LoginDialogView.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINDIALOGVIEW_H
#define UI_LOGINDIALOGVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_LoginDialog
{
public:
    QLineEdit *editUsername;
    QLineEdit *editPassword;
    QPushButton *buttonLogin;
    QPushButton *buttonRegister;
    QPushButton *buttonCancel;

    void setupUi(QDialog *LoginDialog)
    {
        if (LoginDialog->objectName().isEmpty())
            LoginDialog->setObjectName("LoginDialog");
        LoginDialog->resize(400, 300);
        editUsername = new QLineEdit(LoginDialog);
        editUsername->setObjectName("editUsername");
        editUsername->setGeometry(QRect(120, 30, 141, 41));
        editPassword = new QLineEdit(LoginDialog);
        editPassword->setObjectName("editPassword");
        editPassword->setGeometry(QRect(120, 90, 141, 41));
        buttonLogin = new QPushButton(LoginDialog);
        buttonLogin->setObjectName("buttonLogin");
        buttonLogin->setGeometry(QRect(60, 210, 80, 24));
        buttonRegister = new QPushButton(LoginDialog);
        buttonRegister->setObjectName("buttonRegister");
        buttonRegister->setGeometry(QRect(160, 210, 80, 24));
        buttonCancel = new QPushButton(LoginDialog);
        buttonCancel->setObjectName("buttonCancel");
        buttonCancel->setGeometry(QRect(260, 210, 80, 24));

        retranslateUi(LoginDialog);

        QMetaObject::connectSlotsByName(LoginDialog);
    } // setupUi

    void retranslateUi(QDialog *LoginDialog)
    {
        LoginDialog->setWindowTitle(QCoreApplication::translate("LoginDialog", "Dialog", nullptr));
        editUsername->setText(QString());
        buttonLogin->setText(QCoreApplication::translate("LoginDialog", "Login", nullptr));
        buttonRegister->setText(QCoreApplication::translate("LoginDialog", "Register", nullptr));
        buttonCancel->setText(QCoreApplication::translate("LoginDialog", "Exit", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginDialog: public Ui_LoginDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINDIALOGVIEW_H
