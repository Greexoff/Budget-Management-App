/********************************************************************************
** Form generated from reading UI file 'FinancialAccountSelectionView.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FINANCIALACCOUNTSELECTIONVIEW_H
#define UI_FINANCIALACCOUNTSELECTIONVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_FinancialAccountSelectionView
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *addFinancialAccountButton;
    QPushButton *editFinancialAccountButton;
    QPushButton *deleteFinancialAccountButton;
    QPushButton *cancelFinancialAccountButton;
    QTableWidget *financialAccountsTable;
    QLabel *label;
    QLineEdit *searchEdit;

    void setupUi(QDialog *FinancialAccountSelectionView)
    {
        if (FinancialAccountSelectionView->objectName().isEmpty())
            FinancialAccountSelectionView->setObjectName("FinancialAccountSelectionView");
        FinancialAccountSelectionView->resize(795, 552);
        horizontalLayoutWidget = new QWidget(FinancialAccountSelectionView);
        horizontalLayoutWidget->setObjectName("horizontalLayoutWidget");
        horizontalLayoutWidget->setGeometry(QRect(30, 420, 725, 80));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        addFinancialAccountButton = new QPushButton(horizontalLayoutWidget);
        addFinancialAccountButton->setObjectName("addFinancialAccountButton");

        horizontalLayout->addWidget(addFinancialAccountButton);

        editFinancialAccountButton = new QPushButton(horizontalLayoutWidget);
        editFinancialAccountButton->setObjectName("editFinancialAccountButton");

        horizontalLayout->addWidget(editFinancialAccountButton);

        deleteFinancialAccountButton = new QPushButton(horizontalLayoutWidget);
        deleteFinancialAccountButton->setObjectName("deleteFinancialAccountButton");

        horizontalLayout->addWidget(deleteFinancialAccountButton);

        cancelFinancialAccountButton = new QPushButton(horizontalLayoutWidget);
        cancelFinancialAccountButton->setObjectName("cancelFinancialAccountButton");

        horizontalLayout->addWidget(cancelFinancialAccountButton);

        financialAccountsTable = new QTableWidget(FinancialAccountSelectionView);
        financialAccountsTable->setObjectName("financialAccountsTable");
        financialAccountsTable->setGeometry(QRect(30, 80, 731, 311));
        label = new QLabel(FinancialAccountSelectionView);
        label->setObjectName("label");
        label->setGeometry(QRect(610, 30, 41, 21));
        searchEdit = new QLineEdit(FinancialAccountSelectionView);
        searchEdit->setObjectName("searchEdit");
        searchEdit->setGeometry(QRect(650, 30, 113, 24));

        retranslateUi(FinancialAccountSelectionView);

        QMetaObject::connectSlotsByName(FinancialAccountSelectionView);
    } // setupUi

    void retranslateUi(QDialog *FinancialAccountSelectionView)
    {
        FinancialAccountSelectionView->setWindowTitle(QCoreApplication::translate("FinancialAccountSelectionView", "FinancialAccountSelectionView", nullptr));
        addFinancialAccountButton->setText(QCoreApplication::translate("FinancialAccountSelectionView", "Add Financial Account", nullptr));
        editFinancialAccountButton->setText(QCoreApplication::translate("FinancialAccountSelectionView", "Edit Financial Account", nullptr));
        deleteFinancialAccountButton->setText(QCoreApplication::translate("FinancialAccountSelectionView", "Delete Financial Account", nullptr));
        cancelFinancialAccountButton->setText(QCoreApplication::translate("FinancialAccountSelectionView", "Cancel", nullptr));
        label->setText(QCoreApplication::translate("FinancialAccountSelectionView", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class FinancialAccountSelectionView: public Ui_FinancialAccountSelectionView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FINANCIALACCOUNTSELECTIONVIEW_H
