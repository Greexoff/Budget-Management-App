/********************************************************************************
** Form generated from reading UI file 'CategorySelectionView.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CATEGORYSELECTIONVIEW_H
#define UI_CATEGORYSELECTIONVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CategorySelectionView
{
public:
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *addCategoryButton;
    QPushButton *editCategoryButton;
    QPushButton *cancelButton;
    QPushButton *deleteCategoryButton;
    QLabel *label;
    QLineEdit *searchLineEdit;
    QTableWidget *categoryTable;

    void setupUi(QDialog *CategorySelectionView)
    {
        if (CategorySelectionView->objectName().isEmpty())
            CategorySelectionView->setObjectName("CategorySelectionView");
        CategorySelectionView->resize(914, 502);
        horizontalLayoutWidget = new QWidget(CategorySelectionView);
        horizontalLayoutWidget->setObjectName("horizontalLayoutWidget");
        horizontalLayoutWidget->setGeometry(QRect(100, 380, 711, 61));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        addCategoryButton = new QPushButton(horizontalLayoutWidget);
        addCategoryButton->setObjectName("addCategoryButton");

        horizontalLayout->addWidget(addCategoryButton);

        editCategoryButton = new QPushButton(horizontalLayoutWidget);
        editCategoryButton->setObjectName("editCategoryButton");

        horizontalLayout->addWidget(editCategoryButton);

        cancelButton = new QPushButton(horizontalLayoutWidget);
        cancelButton->setObjectName("cancelButton");

        horizontalLayout->addWidget(cancelButton);

        deleteCategoryButton = new QPushButton(horizontalLayoutWidget);
        deleteCategoryButton->setObjectName("deleteCategoryButton");

        horizontalLayout->addWidget(deleteCategoryButton);

        label = new QLabel(CategorySelectionView);
        label->setObjectName("label");
        label->setGeometry(QRect(660, 20, 41, 21));
        searchLineEdit = new QLineEdit(CategorySelectionView);
        searchLineEdit->setObjectName("searchLineEdit");
        searchLineEdit->setGeometry(QRect(700, 20, 113, 24));
        categoryTable = new QTableWidget(CategorySelectionView);
        categoryTable->setObjectName("categoryTable");
        categoryTable->setGeometry(QRect(100, 70, 711, 281));

        retranslateUi(CategorySelectionView);

        QMetaObject::connectSlotsByName(CategorySelectionView);
    } // setupUi

    void retranslateUi(QDialog *CategorySelectionView)
    {
        CategorySelectionView->setWindowTitle(QCoreApplication::translate("CategorySelectionView", "CategorySelectionView", nullptr));
        addCategoryButton->setText(QCoreApplication::translate("CategorySelectionView", "Add Category", nullptr));
        editCategoryButton->setText(QCoreApplication::translate("CategorySelectionView", "Edit Category", nullptr));
        cancelButton->setText(QCoreApplication::translate("CategorySelectionView", "Cancel", nullptr));
        deleteCategoryButton->setText(QCoreApplication::translate("CategorySelectionView", "Delete Category", nullptr));
        label->setText(QCoreApplication::translate("CategorySelectionView", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CategorySelectionView: public Ui_CategorySelectionView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CATEGORYSELECTIONVIEW_H
