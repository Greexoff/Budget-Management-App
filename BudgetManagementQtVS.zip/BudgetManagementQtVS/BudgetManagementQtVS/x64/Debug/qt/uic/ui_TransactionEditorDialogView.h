/********************************************************************************
** Form generated from reading UI file 'TransactionEditorDialogView.ui'
**
** Created by: Qt User Interface Compiler version 6.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRANSACTIONEDITORDIALOGVIEW_H
#define UI_TRANSACTIONEDITORDIALOGVIEW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AddTransactionDialogView
{
public:
    QVBoxLayout *verticalLayout;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *nameEdit;
    QLabel *label_2;
    QDoubleSpinBox *amountSpin;
    QLabel *label_3;
    QDateEdit *dateEdit;
    QLabel *label_4;
    QLineEdit *descriptionEdit;
    QLabel *label_5;
    QComboBox *categoryCombo;
    QLabel *label_6;
    QComboBox *accountCombo;
    QLabel *label_7;
    QComboBox *typeCombo;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *AddTransactionDialogView)
    {
        if (AddTransactionDialogView->objectName().isEmpty())
            AddTransactionDialogView->setObjectName("AddTransactionDialogView");
        AddTransactionDialogView->resize(649, 417);
        verticalLayout = new QVBoxLayout(AddTransactionDialogView);
        verticalLayout->setObjectName("verticalLayout");
        formLayout = new QFormLayout();
        formLayout->setObjectName("formLayout");
        label = new QLabel(AddTransactionDialogView);
        label->setObjectName("label");

        formLayout->setWidget(0, QFormLayout::ItemRole::LabelRole, label);

        nameEdit = new QLineEdit(AddTransactionDialogView);
        nameEdit->setObjectName("nameEdit");

        formLayout->setWidget(0, QFormLayout::ItemRole::FieldRole, nameEdit);

        label_2 = new QLabel(AddTransactionDialogView);
        label_2->setObjectName("label_2");

        formLayout->setWidget(1, QFormLayout::ItemRole::LabelRole, label_2);

        amountSpin = new QDoubleSpinBox(AddTransactionDialogView);
        amountSpin->setObjectName("amountSpin");
        amountSpin->setMinimum(0.010000000000000);
        amountSpin->setMaximum(1000000000.000000000000000);
        amountSpin->setValue(0.010000000000000);

        formLayout->setWidget(1, QFormLayout::ItemRole::FieldRole, amountSpin);

        label_3 = new QLabel(AddTransactionDialogView);
        label_3->setObjectName("label_3");

        formLayout->setWidget(2, QFormLayout::ItemRole::LabelRole, label_3);

        dateEdit = new QDateEdit(AddTransactionDialogView);
        dateEdit->setObjectName("dateEdit");
        dateEdit->setCalendarPopup(true);

        formLayout->setWidget(2, QFormLayout::ItemRole::FieldRole, dateEdit);

        label_4 = new QLabel(AddTransactionDialogView);
        label_4->setObjectName("label_4");

        formLayout->setWidget(3, QFormLayout::ItemRole::LabelRole, label_4);

        descriptionEdit = new QLineEdit(AddTransactionDialogView);
        descriptionEdit->setObjectName("descriptionEdit");

        formLayout->setWidget(3, QFormLayout::ItemRole::FieldRole, descriptionEdit);

        label_5 = new QLabel(AddTransactionDialogView);
        label_5->setObjectName("label_5");

        formLayout->setWidget(5, QFormLayout::ItemRole::LabelRole, label_5);

        categoryCombo = new QComboBox(AddTransactionDialogView);
        categoryCombo->setObjectName("categoryCombo");

        formLayout->setWidget(5, QFormLayout::ItemRole::FieldRole, categoryCombo);

        label_6 = new QLabel(AddTransactionDialogView);
        label_6->setObjectName("label_6");

        formLayout->setWidget(6, QFormLayout::ItemRole::LabelRole, label_6);

        accountCombo = new QComboBox(AddTransactionDialogView);
        accountCombo->setObjectName("accountCombo");

        formLayout->setWidget(6, QFormLayout::ItemRole::FieldRole, accountCombo);

        label_7 = new QLabel(AddTransactionDialogView);
        label_7->setObjectName("label_7");

        formLayout->setWidget(4, QFormLayout::ItemRole::LabelRole, label_7);

        typeCombo = new QComboBox(AddTransactionDialogView);
        typeCombo->setObjectName("typeCombo");

        formLayout->setWidget(4, QFormLayout::ItemRole::FieldRole, typeCombo);


        verticalLayout->addLayout(formLayout);

        buttonBox = new QDialogButtonBox(AddTransactionDialogView);
        buttonBox->setObjectName("buttonBox");
        buttonBox->setOrientation(Qt::Orientation::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::StandardButton::Cancel|QDialogButtonBox::StandardButton::Save);

        verticalLayout->addWidget(buttonBox);


        retranslateUi(AddTransactionDialogView);
        QObject::connect(buttonBox, &QDialogButtonBox::accepted, AddTransactionDialogView, qOverload<>(&QDialog::accept));
        QObject::connect(buttonBox, &QDialogButtonBox::rejected, AddTransactionDialogView, qOverload<>(&QDialog::reject));

        QMetaObject::connectSlotsByName(AddTransactionDialogView);
    } // setupUi

    void retranslateUi(QDialog *AddTransactionDialogView)
    {
        AddTransactionDialogView->setWindowTitle(QCoreApplication::translate("AddTransactionDialogView", "Add New Transaction", nullptr));
        label->setText(QCoreApplication::translate("AddTransactionDialogView", "Name:", nullptr));
        label_2->setText(QCoreApplication::translate("AddTransactionDialogView", "Amount:", nullptr));
        label_3->setText(QCoreApplication::translate("AddTransactionDialogView", "Date:", nullptr));
        dateEdit->setDisplayFormat(QCoreApplication::translate("AddTransactionDialogView", "yyyy-MM-dd", nullptr));
        label_4->setText(QCoreApplication::translate("AddTransactionDialogView", "Description:", nullptr));
        label_5->setText(QCoreApplication::translate("AddTransactionDialogView", "Category:", nullptr));
        label_6->setText(QCoreApplication::translate("AddTransactionDialogView", "<html><head/><body><p>Financial<br/>Account:</p></body></html>", nullptr));
        label_7->setText(QCoreApplication::translate("AddTransactionDialogView", "Type:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddTransactionDialogView: public Ui_AddTransactionDialogView {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRANSACTIONEDITORDIALOGVIEW_H
